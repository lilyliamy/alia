const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const chefImg = new Image();
chefImg.src = "https://i.postimg.cc/GhYgBv34/Adobe-Express-file.png";

let chef = {
    x: canvas.width / 2 - 50,
    y: canvas.height - 80,
    width: 100,
    height: 80,
    speed: 10,
    movingLeft: false,
    movingRight: false
};

let correctFoods = [
    { img: "https://i.postimg.cc/rF0Cn4Dq/IMG-20250211-151133-245.jpg" },
    { img: "https://i.postimg.cc/nLrntnBY/IMG-20250211-151133-451.jpg" },
    { img: "https://i.postimg.cc/MGmVgb0j/Bulgogi-Steak-Kabobs-Feature.jpg" }
];

let wrongFoods = [
    { img: "https://i.postimg.cc/TPBXbSHr/milk.jpg" },
    { img: "https://i.postimg.cc/DZfMY3YV/raw-chick.jpg" }
];

let fallingFoods = [];
let score = 0;
let timeLeft = 60;
let gameActive = false;
let timerInterval;
let foodInterval;

function startGame() {
    document.querySelector('.start-btn').style.display = 'none';
    document.getElementById("timeoutBox").style.display = 'none';
    document.getElementById("coinBox").style.display = 'none';

    score = 0;
    timeLeft = 60;
    fallingFoods = [];
    gameActive = true;
    document.getElementById("score").innerText = "Score: 0";
    document.getElementById("timer").innerText = "Time: 60";

    timerInterval = setInterval(updateTimer, 1000);
    foodInterval = setInterval(spawnFood, 800);
    updateGame();
}

function updateTimer() {
    if (timeLeft > 0) {
        timeLeft--;
        document.getElementById("timer").innerText = "Time: " + timeLeft;
    } else {
        endGame();
    }
}

function spawnFood() {
    if (!gameActive) return;

    let foodList = Math.random() > 0.5 ? correctFoods : wrongFoods;
    let food = foodList[Math.floor(Math.random() * foodList.length)];

    fallingFoods.push({
        x: Math.random() * (canvas.width - 50),
        y: 0,
        img: food.img,
        type: foodList === correctFoods ? "correct" : "wrong",
        speed: Math.random() * 3 + 2
    });
}

function updateGame() {
    if (!gameActive) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawChef();
    drawFoods();
    moveFoods();
    detectCollision();

    if (chef.movingLeft) chef.x -= chef.speed;
    if (chef.movingRight) chef.x += chef.speed;
    chef.x = Math.max(0, Math.min(canvas.width - chef.width, chef.x));

    document.getElementById("score").innerText = "Score: " + score;
    if (score >= 80) {
        document.getElementById("coinBox").style.display = 'block';
    }
    requestAnimationFrame(updateGame);
}

function drawChef() {
    ctx.drawImage(chefImg, chef.x, chef.y, chef.width, chef.height);
}

function drawFoods() {
    fallingFoods.forEach(food => {
        let img = new Image();
        img.src = food.img;
        
        ctx.save();
        ctx.beginPath();
        ctx.arc(food.x + 25, food.y + 25, 25, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, food.x, food.y, 50, 50);
        ctx.restore();
    });
}

function moveFoods() {
    fallingFoods.forEach(food => {
        food.y += food.speed;
    });
}

function detectCollision() {
    fallingFoods = fallingFoods.filter(food => {
        if (
            food.y + 50 >= chef.y &&
            food.x + 50 > chef.x &&
            food.x < chef.x + chef.width
        ) {
            score += food.type === "correct" ? 1 : -1;
            return false;
        }
        return food.y < canvas.height;
    });
}

function endGame() {
    gameActive = false;
    clearInterval(timerInterval);
    clearInterval(foodInterval);
    document.getElementById("timeoutBox").style.display = 'block';
}

function restartGame() {
    document.getElementById("timeoutBox").style.display = 'none';
    startGame();
}

document.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft") chef.movingLeft = true;
    if (e.key === "ArrowRight") chef.movingRight = true;
});

document.addEventListener("keyup", () => {
    chef.movingLeft = chef.movingRight = false;
});
